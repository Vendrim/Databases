PROMPT Daten für die Datenbank
PROMPT -----------------------------------------
PROMPT Fortfahen? ( ENTER = JA )
PAUSE

INSERT INTO ACCOUNT(BENUTZERNAME, EMAIL, PASSWORD)
VALUES 
  ('John Doe' , 'john.doe@hotmail.com', '1234567890');


INSERT INTO ACCOUNT(BENUTZERNAME, EMAIL, PASSWORD)
VALUES 
  ('Joe Schmoe' , 'john.schmoe24@gmail.com', 'schmojoe');


INSERT INTO ACCOUNT(BENUTZERNAME, EMAIL, PASSWORD)
VALUES 
  ('Max Mustermann' , 'max.mustermann@gmx.de', 'musterpassword12!');


INSERT INTO ACCOUNT(BENUTZERNAME, EMAIL, PASSWORD)
VALUES 
  ('Dr. Anton Hirschhorn' , 'a.hirsch@protonmail.com', 'password');


INSERT INTO ACCOUNT(BENUTZERNAME, EMAIL, PASSWORD)
VALUES 
  ('Maria Filaminosa' , 'maria.fila@gmail.com', 'Antonietta');


INSERT INTO ACCOUNT(BENUTZERNAME, EMAIL, PASSWORD)
VALUES 
  ('Rosa Rosetta' , 'rose123@hotmail.com', 'Ich mag Rosen!');



PROMPT Table Account befüllt.
PROMPT ---------------------------------------
PROMPT 
PAUSE


INSERT INTO SPIEL(TITEL, ENTWICKLERSTUDIO, LEIHPREIS, KAUFPREIS)
VALUES 
  ('TES V - Skyrim' , 'Bethesda', 5.99, 39.99);

INSERT INTO SPIEL(TITEL, ENTWICKLERSTUDIO, LEIHPREIS, KAUFPREIS)
VALUES 
  ('TES III - Morrowind' , 'Bethesda', 0.99, 10.99);

INSERT INTO SPIEL(TITEL, ENTWICKLERSTUDIO, LEIHPREIS, KAUFPREIS)
VALUES 
  ('FatSquirrel' , 'HS-AUGSBURG', 0.29, 2.99);

INSERT INTO SPIEL(TITEL, ENTWICKLERSTUDIO, LEIHPREIS, KAUFPREIS)
VALUES 
  ('Sid Meiers Civilization VI' , 'Firaxis', 4.99, 35.99);


PROMPT Table Spiel befüllt.
PROMPT ---------------------------------------
PROMPT 
PAUSE



INSERT INTO BEWERTUNG(BENUTZERNAME,TITEL, NOTE, KOMMENTAR)
VALUES 
  ('Joe Schmoe' , 'TES V - Skyrim', 5.0 , 'Amazing Game! 5/5. Will play again!');

INSERT INTO SPIEL(TITEL, ENTWICKLERSTUDIO, LEIHPREIS, KAUFPREIS)
VALUES 
  ('Dr. Anton Hirschhorn' , 'Sid Meiers Civilization VI', 3.2, 'Leider muss ich sagen, dass ich CIV V besser fand als dieses hier. Da konnte man zumindest die Straßen selber bauen!');

INSERT INTO BEWERTUNG(BENUTZERNAME,TITEL, NOTE, KOMMENTAR)
VALUES 
  ('Maria Filaminosa' , 'FatSquirrel', 1.0 , 'Blutrünstiges Spiel . Mein Kind ist traumatisiert. Wie kann ma nur so etwas verantwortungsloses online stellen!');


INSERT INTO BEWERTUNG(BENUTZERNAME,TITEL, NOTE, KOMMENTAR)
VALUES 
  ('John Doe' , 'FatSquirrel', 3.0 , 'Ausgewogenes Spielerlebnis. Jedoch stören die Bugs bei am Anfang und beim Gameplay. Nachbesserungsbedarf!!!');



PROMPT Table Bewertung befüllt.
PROMPT ---------------------------------------
PROMPT 
PAUSE


INSERT INTO BESTELLUNG(BENUTZERNAME,DATUM, VERWENDETE ZAHLUNGSMÖGLICHKEIT)
VALUES 
  ('Maria Filaminosa' , 'TO_DATE(12/06/2019)', 'PayPal');


INSERT INTO BESTELLUNG(BENUTZERNAME,DATUM, VERWENDETE ZAHLUNGSMÖGLICHKEIT)
VALUES 
  ('John Doe' , 'TO_DATE(09/04/2017)', 'Debit-Karte');

INSERT INTO BESTELLUNG(BENUTZERNAME,DATUM, VERWENDETE ZAHLUNGSMÖGLICHKEIT)
VALUES 
  ('Dr. Anton Hirschhorn' , 'TO_DATE(12/03/1946)', 'Visa');

INSERT INTO BESTELLUNG(BENUTZERNAME,DATUM, VERWENDETE ZAHLUNGSMÖGLICHKEIT)
VALUES 
  ('Joe Schmoe' , 'TO_DATE(01/04/2020)', 'PayPal');


PROMPT Table Bestellung befüllt.
PROMPT ---------------------------------------
PROMPT 
PAUSE


INSERT INTO BESTELLPOSITION(TITEL,BENUTZERNAME,DATUM, ABLAUFDATUM)
VALUES 
  ('TES V - Skyrim','Joe Schmoe' , 'TO_DATE(01/04/2020)', TO_DATE('01/09/2020'));


INSERT INTO BESTELLPOSITION(TITEL,BENUTZERNAME,DATUM)
VALUES 
  ('Sid Meiers Civilization VI','Dr. Anton Hirschhorn' , TO_DATE('12/03/1946'), TO_DATE('12/03/2046'));


PROMPT Table Bestellungsposition befüllt.
PROMPT ---------------------------------------
PROMPT 
PAUSE


INSERT INTO SPIELSPRACHE(TITEL,SPRACHE)
VALUES 
  ('Sid Meiers Civilization VI','DEUTSCH');

INSERT INTO SPIELSPRACHE(TITEL,SPRACHE)
VALUES 
  ('FatSquirrel','RUSSISCH');
																						
																						
PROMPT Table  SPIELSPRACHE befüllt.
PROMPT ---------------------------------------
PROMPT 
PAUSE																						
																						
INSERT INTO SPIELBUENDLE(RABATT,GENRE,TITEL)
VALUES 
  (20,'ACTION', 'TES III - Morrowind');
									

																					
INSERT INTO SPIELBUENDLE(RABATT,GENRE,TITEL)
VALUES 
  (30,'FUN', 'Sid Meiers Civilization VI');	
																						I
PROMPT Table SPIELBUENDLE befüllt.
PROMPT ---------------------------------------
PROMPT 
PAUSE		

INSERT INTO BUENDLE(RABATT,GENRE)
VALUES 
  (30,'FUN');	
																						
INSERT INTO BUENDLE(RABATT,GENRE)
VALUES 																						
  (20,'ACTION');		
																						
PROMPT Table BUENDLE befüllt.
PROMPT ---------------------------------------
PROMPT 
PAUSE																						
																						
INSERT INTO BESTELLUNG/BUENDLE(BENUTZERNAME,DATUM,RABATT,GENRE)																					
VALUES 
  ('Maria Filaminosa' , 'TO_DATE(12/06/2019)', 30,'FUN');
																						
INSERT INTO BESTELLUNG/BUENDLE(BENUTZERNAME,DATUM,RABATT,GENRE)																					
VALUES 
  ('John Doe' , 'TO_DATE(09/04/2017)', 20,'ACTION');
																						
PROMPT Table BESTELLUNG/BUENDLE befüllt.
PROMPT ---------------------------------------
PROMPT 
PROMPT ALLES BEFUELLT!!!!!
PAUSE																							