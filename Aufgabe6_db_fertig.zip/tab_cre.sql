-- Account: ( (Benutzernamex), Email, Passwort)
-- Spiel : ((Titel), Entwicklerstudio, Leihpreis, Kaufpreis)
-- Bewertung: ((Benutzername, Titel), Note, Kommentar)
-- Bestellung:( (Benutzername, Datum), verwendete Zahlungsmöglichkeit)
-- Bestellposition:((Titel, Benutzername, Datum), Ablaufdatum)
-- Spielsprache:((Titel, Sprache))
-- Spielbundle:((Rabatt, Genre,Titel))
-- Bestellung/Bundle:((Benutzername, Datum, Rabatt, Genre))
prompt ----------------------------------------------------------------------------
prompt Datenbank Games as a Service
prompt 			
prompt ----------------------------------------------------------------------------
prompt				
prompt Datenbank erzeugen? (ENTER = JA)
pause

prompt Tabelle Account
prompt ----------------------------------------------------------------------------
pause

create table account (
	Benutzername varchar(255) not null primary key,
	Email varchar(255) not null,
	Passwort varchar(255) not null
);

prompt Tabelle Bundle
prompt ----------------------------------------------------------------------------
pause

create table bundle (
	Rabatt int() not null primary key,
	Genre varchar(255) not null primary key
);

prompt Tabelle Spiel
prompt ----------------------------------------------------------------------------
pause

create table spiel (
	Titel varchar(255) not null primary key,
	Entwicklerstudio varchar(255) not null,
	Leihpreis varchar(255) not null,
	Kaufpreis varchar(255) not null,
	CONSTRAINT spiele_ch_leihpreis CHECK (leihpreis >= 0 ),
 	CONSTRAINT spiele_ck_kaufpreis CHECK (kaufpreis >= 0)
);

prompt Tabelle Bewertung
prompt ----------------------------------------------------------------------------
pause

create table Bewertung ( 
	Benutzername varchar(255) not null primary key,
	Titel varchar(255) not null primary key,
	Note number(3,2) not null,
	Kommentar varchar(255),
	CONSTRAINT bewertung_ck_note CHECK (note >= 0 && note <= 5 )
);

prompt Tabelle Bestellung
prompt ----------------------------------------------------------------------------
pause

create table Bestellung: (
	Benutzername varchar(255) not null primary key,
	Datum date(dd/mm/yyyy),
	verwendete Zahlugsmöglichkeit varchar(255) not null
);

prompt Tabelle Bestellposition
prompt ----------------------------------------------------------------------------
pause

create table Bestellposition:(
	Titel varchar(255) not null primary key,
	Benutzername varchar(255) not null primary key,
	Datum date(dd/mm/yyyy) primary key,
	Ablaufdatum date(dd/mm/yyyy) not null
);

prompt Tabelle Spielsprache
prompt ----------------------------------------------------------------------------
pause

create table Spielsprache(
	Titel varchar(255) not null primary key,
	Sprache varchar(255) not null primary key
);

prompt Tabelle Spielbundle
prompt ----------------------------------------------------------------------------
pause

create table Spielbundle ( 
	Rabatt int() not null primary key,
	Genre varchar(255) not null primary key,
	Titel varchar(255) primary key
);

prompt Tabelle Bestellung/Bundle
prompt ----------------------------------------------------------------------------
pause

create table Bestellung/Bundle:(
	Benutzername varchar(255) primary key,
	Datum date(dd/mm/yyyy) primary key,
	Rabatt int() primary key,
	Genre varchar(255) primary key
);



