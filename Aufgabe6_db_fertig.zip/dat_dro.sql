Prompt Löscht die Datenbankendaten
Prompt --------------------------------
Prompt Fortfahren(ENTER = JA)
PAUSE 

DELETE FROM ACCOUNT
PROMPT Lösche Table Account

DELETE FROM SPIEL
PROMPT Lösche Table Spiel

DELETE FROM SPIELSPRACHE
PROMPT Lösche Table Spielsprache

DELETE FROM BESTELLUNG
PROMPT Lösche Table Bestellung

DELETE FROM BESTELLPOSITION
PROMPT Lösche Table Bestellposition

DELETE FROM BUNDLE
Prompt Lösche Table Bundle

DELETE FROM BESTELLUNG/BUNDLE
Prompt Lösche Table Bestellung/Bundle

DELETE FROM BEWERTUNG
Prompt Lösche TableBewertung

DELETE FROM SPIELBUNDLE
Prompt Lösche Table Spielbundle

Prompt Fertig!

Pause


